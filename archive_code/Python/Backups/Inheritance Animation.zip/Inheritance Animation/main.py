from ASCII_Canvas import *
from Canvas_Wrapper import *

if __name__ == "__main__":
#  app = ASCII_Canvas()
  app = Canvas_Wrapper()
  app.mainloop()

