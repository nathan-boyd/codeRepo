from Tkinter import *
import Tkinter
from Panel import*
from Canvas import *
from Animator import *

import tkFileDialog

class Canvas(Tk):
  def __init__(self): 
    Tk.__init__(self)

    self.fileName = ""
    self.ASCII_Panels = []

    self.configure(bg="white")  
    self.title("Canvas Wrapper")

    mainFrame = Frame(self, bg="white")
    designFrame = Frame(self, bg="white")

    #can place arrows and button images on these
    self.quitButton = Button(mainFrame, text="QUIT", fg="red", command=self.quit).grid(row=0,column=1)
    self.importButton = Button(mainFrame, text="Import ASCII", fg="blue", command=lambda: self.ImportFile("new")).grid(row=0,column=2)
    self.animateButton = Button(mainFrame, text="Animate", fg="blue", command=lambda: self.MakeAnimation()).grid(row=0,column=3)
    self.stepRightButton = Button(mainFrame, text="Step Right", fg="blue", command=lambda: self.Step("right")).grid(row=0,column=4)
    self.stepLeftButton = Button(mainFrame, text="Step Left", fg="blue", command=lambda: self.Step("left")).grid(row=0,column=0)

    self.textArea = Text(designFrame, state="normal")

    self.textArea.grid()
    mainFrame.grid()
    designFrame.grid()

  def Step(self, direction):

    if self.fileName == "":                                    #If the file name is empty load up a new file
      self.ImportFile("old")

    self.SavePanel()
    self.textArea.delete(1.0,END)

    if direction == "left":
      self.currentFrame -= 1
    elif direction == "right":
      self.currentFrame += 1

    print "Current frame " + str(self.currentFrame) + " Total Frames " + str(self.totalFrame)
    tempPanel = self.ASCII_Panels[self.currentFrame].getPanel()

    for index in range(len(tempPanel)):
      self.textArea.insert(INSERT, tempPanel[index])
      self.textArea.insert(INSERT, "\n")

    self.update()

  def SavePanel(self):

    #add & at end of panel, add newline char at end of line

    aBuffer_Panels = []
    
    temp = self.textArea.get(1.0, END)
    panel = Panel(temp)
 #   aBuffer_Panels.append(panel)

    #need to save the new panel to the .ascii fiel 

    file = open("temp.tmp",'w')
    file.write(panel.getPanel())
    file.close()

    self.UpdateAnimation()
    self.SaveASCII()

  def SaveASCII(self):                                        #wrtie the entire list to file
    file = open("saved_ascii.ascii", 'w')
    for index in range(len(self.ASCII_Panels)):
      panel = Panel(self.ASCII_Panels[index])
      file.write(panel.getPanel())
    file.close
      
  def UpdateAnimation(self):
    localPanel = []
    f = open("temp.tmp", 'r')
    for row in f:
      localPanel.append(row.rstrip())
      if row.count("&") != 0:
        panel = Panel(localPanel)
        del localPanel
        localPanel = []                   
        self.totalFrame +=1
        self.ASCII_Panels[self.currentFrame] = panel
    f.close()

  def ImportFile(self, type):    #type refers to whether we need to open a new file or simply reload the current one

    self.currentFrame = -1
    self.totalFrame = 0
    
    if type == "new":
      self.fileName = ""
    
    if self.fileName == "":
      #self.fileName = tkFileDialog.askopenfilename()    
      self.fileName = "ASCII ART/FishTank.ascii"
      self.ImportFile("old")
    else:
      localPanel = []
      f = open(self.fileName, 'r')
      for row in f:
        localPanel.append(row.rstrip())
        if row.count("&") != 0:
          panel = Panel(localPanel)
          del localPanel
          localPanel = []                   
          self.totalFrame +=1
          self.ASCII_Panels.append(panel)
      f.close()

  def MakeAnimation(self):                                       #passes a file name to the Animator class
    if self.fileName != "":
      print "Making Animation"
      self.newAnimator = Animator(self.fileName)  
      self.newAnimator.Animate()
      self.newAnimator.destroy()
    else:
      print "No file Loaded"
      self.ImportFile()
      self.MakeAnimation()

def main():
  print "Canvas Main called"
  canvas = Canvas()
  canvas.mainloop()
  
if __name__ == "__main__":
  main()
