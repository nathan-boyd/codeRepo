from Tkinter import *
import tkFileDialog
import time

class Animator(Tk):
  def __init__(self, fileName): #two inits to call the parent class
    Tk.__init__(self)

    self.title("ASCII Animator")
    self.configure(bg="white")
    self.aASCII = [] 
    self.fileName = fileName
    self.ImportFile()

  def getASCII(self):
    return self.aASCII

  def ImportFile(self):    
    self.ASCII_Height = 0
    self.ASCII_Width = 0

    with open(self.fileName) as f:
      line = 0
      for row in f:
        line += 1
        if row.count("&") != 0:
          if self.ASCII_Width < row.find("&"):
            self.ASCII_Width = row.find("&")
          if self.ASCII_Height == 0:
            self.ASCII_Height = line
        self.aASCII.append(row.rstrip())
    
  def Animate(self):

    self.textArea = Text(self, height=self.ASCII_Height, width=self.ASCII_Width)

    for index in range(len(self.aASCII)):
      self.textArea.insert(INSERT, self.aASCII[index])
      self.textArea.insert(INSERT, "\n")

      if self.aASCII[index].count("&") != 0:
        self.textArea.grid()
        self.update()
        time.sleep(.25)
        self.textArea.delete(1.0,END)       

def main():
  print "Animator main called\n"
  animator = Animator("ASCII ART/FishTank.ascii")
  animator.Animate()
  animator.destroy()

  
if __name__ == "__main__":
  main()
