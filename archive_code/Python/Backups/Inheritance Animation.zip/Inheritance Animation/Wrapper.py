from Canvas import*
from Animator import*

class Wrapper():

  def main():

    newCanvas = Canvas()
  
if __name__ == "__main__":
  main()
