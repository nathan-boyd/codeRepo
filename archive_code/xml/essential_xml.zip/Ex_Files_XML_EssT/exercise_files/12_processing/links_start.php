<?php

function startElemHandler($parser, $name, $attribs) 
{
}

function endElemHandler($parser, $name)
{
}


?>